<?php
namespace AliyunMNS\Exception;

use AliyunMNS\Exception\MnsException;

class InvalidArgumentException extends MnsException
{
}

?>
